apt update -y 

apt install default-jdk -y

apt install tomcat9 tomcat9-admin -y




## <user= username="tomcat" password="tomcat" roles="manager-gui,admin-gui,manager-script"/>

